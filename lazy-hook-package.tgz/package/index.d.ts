/// <reference path="./phoenix_live_view.augment.d.ts" />

import { ViewHook } from "phoenix_live_view";

type ViewLike = {
  isDead?: boolean;
  viewHooks: Record<string, ViewHook | undefined>;
};
type ViewHookConstructorArgs<E extends HTMLElement = HTMLElement> = [
  view: ViewLike | null,
  el: E,
  callbacks?: unknown,
];
type ViewHookClass = new (...args: ViewHookConstructorArgs) => ViewHook;
type ViewHookModule<ExportName extends string> = Record<
  ExportName,
  ViewHookClass
> &
  Partial<Record<string, unknown>>;
type ViewHookLoader<ExportName extends string> = () => Promise<
  ViewHookModule<ExportName>
>;

export type LazyHookState = {
  realHook?: ViewHook;
  loading?: Promise<void>;
  destroyed: boolean;
  queuedUpdated: boolean;
};

export declare function stateFor(hook: ViewHook): LazyHookState;

export declare function lazyHook(
  load: ViewHookLoader<"default">,
): ViewHookClass;
export declare function lazyHook<ExportName extends string>(
  load: ViewHookLoader<ExportName>,
  exportName: ExportName,
): ViewHookClass;
