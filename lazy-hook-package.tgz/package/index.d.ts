/// <reference path="./phoenix_live_view.augment.d.ts" />

import { ViewHook } from "phoenix_live_view";

type ViewHookClass = new (
  ...args: ConstructorParameters<typeof ViewHook>
) => ViewHook;
type ViewHookModule<ExportName extends string> = Record<
  ExportName,
  ViewHookClass
> &
  Partial<Record<string, unknown>>;
type ViewHookLoader<ExportName extends string> = () => Promise<
  ViewHookModule<ExportName>
>;

export type LazyHookState = {
  realHook?: ViewHook;
  loading?: Promise<void>;
  destroyed: boolean;
  queuedUpdated: boolean;
};

export declare function stateFor(hook: ViewHook): LazyHookState;

export declare function lazyHook(
  load: ViewHookLoader<"default">,
): ViewHookClass;
export declare function lazyHook<ExportName extends string>(
  load: ViewHookLoader<ExportName>,
  exportName: ExportName,
): ViewHookClass;
